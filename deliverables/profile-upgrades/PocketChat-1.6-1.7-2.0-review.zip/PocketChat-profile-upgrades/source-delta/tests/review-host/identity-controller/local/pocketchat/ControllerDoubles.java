package local.pocketchat;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import org.json.JSONObject;

/** Host doubles for Android/UI, persistence I/O and service access. The controller,
 * immutable model and template validation under test are production sources. */
final class WorkQueue implements Executor {
  final ArrayDeque<Runnable> tasks=new ArrayDeque<>();
  public void execute(Runnable work){tasks.add(work);}
  boolean post(Runnable work){tasks.add(work);return true;}
  void run(){while(!tasks.isEmpty())tasks.remove().run();}
}
final class FakeContext {EnvironmentSpec.NetworkBinding actual;}
final class FakePrefs {
  String mode="external",proxy="";
  String getString(String name,String fallback){return "networkMode".equals(name)?mode:"proxy".equals(name)?proxy:fallback;}
}
final class FakeGuard {boolean allowed=true;boolean allowed(){return allowed;}}
final class FakeAudit {String policy="policy",route="route";String policyStamp(){return policy;}String routeStamp(){return route;}}
final class FakeSettings {boolean policyAcknowledged=true;JSONObject acceptedBrowserIdentity;}
final class FakeWeb {
  long identityPolicyRevision=1;final FakeSettings settings=new FakeSettings();BrowserIdentitySpec configured;
  boolean identityPrepared;
  FakeSettings getSettings(){return settings;}
  void configureIdentity(BrowserIdentitySpec specification){configured=specification;}
  void identityConfigurationReady(){if(configured==null)throw new AssertionError("Identity gate opened before configuration");identityPrepared=true;}
}
final class BrowserPrivacy {
  int protection=1,applications;boolean desktop;
  int level(){return protection;}boolean wantsDesktop(){return desktop;}void apply(){applications++;}
}
final class ChatSession {
  final FakeContext context=new FakeContext();final FakePrefs prefs=new FakePrefs();
  final WorkQueue environmentIo=new WorkQueue(),handler=new WorkQueue();
  final FakeGuard guard=new FakeGuard();final FakeAudit audit=new FakeAudit();final FakeWeb web=new FakeWeb();
  final BrowserPrivacy privacy=new BrowserPrivacy();
  boolean deleted,offline,networkReady=true,identityApplicationPending,deferred,failQueue;
  int environmentGeneration,queuedLevel,queuedSaves;boolean queuedDesktop;
  long connectionEpoch=1;String environmentSpecIssue="";IdentityTemplateController identity;
  boolean internalNetwork(){return "internal".equals(prefs.mode);}
}
final class MainActivity {
  ChatSession session;boolean destroyed,finishing;MainActivity(ChatSession session){this.session=session;}
  boolean isDestroyed(){return destroyed;}boolean isFinishing(){return finishing;}
}
final class GeckoWebView {static final String VERSION="GeckoView host-controller-fixture";}
final class NativeNetwork {
  static final NativeNetwork instance=new NativeNetwork();JSONObject settings=new JSONObject();
  boolean exactReceipt=true;NetworkHealthPolicy.Admission admission=NetworkHealthPolicy.Admission.VERIFIED;
  static NativeNetwork get(FakeContext context){return instance;}
  boolean verifiedRouteCurrent(){return exactReceipt;}
  NetworkHealthPolicy.Admission connectionAdmission(){return admission;}
}
final class DeferredBrowserSettings {
  static boolean pending(ChatSession session){return session.deferred;}
  static boolean save(ChatSession session,int level,boolean desktop){if(session.failQueue)return false;session.deferred=true;session.queuedLevel=level;session.queuedDesktop=desktop;session.queuedSaves++;return true;}
}
final class EnvironmentSpecRepository {
  static EnvironmentSpec value;static int appliedWrites,observedWrites;
  static boolean readFailure;
  EnvironmentSpecRepository(FakeContext context){}
  EnvironmentSpec load()throws java.io.IOException{if(readFailure)throw new java.io.IOException("Synthetic encrypted read failure");return value;}
  EnvironmentSpec updateDesired(EnvironmentSpec.Identity expected,long revision,EnvironmentSpec.Configuration configuration)throws Exception{
    if(!value.identity.equals(expected))throw new java.io.IOException("Identity changed");
    return value=value.withDesired(revision,configuration);
  }
  EnvironmentSpec markApplied(EnvironmentSpec.Identity expected,long revision,String engine)throws Exception{
    if(!value.identity.equals(expected))throw new java.io.IOException("Identity changed");
    value=value.withApplied(revision,engine,1);appliedWrites++;return value;
  }
  EnvironmentSpec recordObservation(EnvironmentSpec.Identity expected,long revision,JSONObject observation)throws Exception{
    if(!value.identity.equals(expected))throw new java.io.IOException("Identity changed");
    value=value.withObservation(revision,observation,1);observedWrites++;return value;
  }
}
final class EnvironmentSpecRuntime {
  static EnvironmentSpec desireBrowser(FakeContext context,JSONObject browser)throws Exception{
    EnvironmentSpec before=EnvironmentSpecRepository.value;
    return new EnvironmentSpecRepository(context).updateDesired(before.identity,before.desiredRevision,new EnvironmentSpec.Configuration(browser,before.desired().network));
  }
  static EnvironmentSpec.NetworkBinding binding(FakeContext context,String mode,JSONObject settings,String proxy){return context.actual;}
}
final class EnvironmentEditorUi {
  static int writes;static final List<Pending> pending=new ArrayList<>();
  static final class Pending {
    final MainActivity activity;final JSONObject values;final BooleanSupplier current;final Consumer<Boolean> done;
    Pending(MainActivity activity,JSONObject values,BooleanSupplier current,Consumer<Boolean> done){this.activity=activity;this.values=values;this.current=current;this.done=done;}
    void finish(){if(!current.getAsBoolean()){done.accept(false);return;}writes++;done.accept(true);}
  }
  static JSONObject current(MainActivity activity){return J.obj("name","host fixture");}
  static void applySafely(MainActivity activity,JSONObject values,android.widget.EditText name,BooleanSupplier current,Consumer<Boolean> done){pending.add(new Pending(activity,values,current,done));}
}
